ALTER TABLE [#__languages] ADD [access] [bigint] NOT NULL DEFAULT 0;
